#ifndef __KEY_H__
#define __KEY_H__
#include "main.h"

extern int i,time_count;

void key_scanf(void);
#endif


