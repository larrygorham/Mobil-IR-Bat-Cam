#ifndef __LED_H__
#define __LED_H__


void led_update(void);
#endif


